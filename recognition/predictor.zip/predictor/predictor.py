"""
Gesture Predictor.

Runs end-to-end inference on a single image.
"""

from __future__ import annotations

import numpy as np
import tensorflow as tf

from recognition.network import GestureRecognitionModel

from .hand_detector import HandDetector
from .preprocessor import Preprocessor


class Predictor:
    """
    High-level inference pipeline.
    """

    def __init__(
        self,
        model: GestureRecognitionModel,
        class_names: list[str],
    ):

        self.model = model

        self.class_names = class_names

        self.detector = HandDetector()

        self.preprocessor = Preprocessor()

    # =====================================================
    # Predict
    # =====================================================

    def predict(
        self,
        image: np.ndarray,
    ) -> dict | None:
        """
        Predict gesture from an RGB image.

        Returns
        -------
        dict | None
        """

        hand = self.detector.detect(image)

        if hand is None:

            return None

        inputs = self.preprocessor.preprocess(

            image,

            hand.landmarks,

        )

        logits = self.model(

            inputs,

            training=False,

        )

        probabilities = tf.nn.softmax(

            logits,

            axis=-1,

        ).numpy()[0]

        predicted_index = int(

            np.argmax(probabilities)

        )

        confidence = float(

            probabilities[predicted_index]

        )

        return {

            "gesture": self.class_names[predicted_index],

            "label": predicted_index,

            "confidence": confidence,
 
            "probabilities": probabilities,

            "handedness": hand.handedness,

            "bounding_box": hand.bounding_box,

            "hand": hand,

        }

    # =====================================================
    # Cleanup
    # =====================================================

    def close(self):

        self.detector.close()