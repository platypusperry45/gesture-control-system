"""
Model Loader.

Loads trained GestureRecognitionModel weights.
"""

from __future__ import annotations

from pathlib import Path

from recognition.network import GestureRecognitionModel


class ModelLoader:
    """
    Loads a trained gesture recognition model.
    """

    def __init__(
        self,
        num_classes: int,
    ):

        self.num_classes = num_classes

    # =====================================================
    # Public API
    # =====================================================

    def load(
        self,
        checkpoint_path: str | Path,
    ) -> GestureRecognitionModel:
        """
        Build model and load weights.
        """

        checkpoint_path = Path(checkpoint_path)

        model = GestureRecognitionModel.build_model(

            num_classes=self.num_classes,

        )

        model.load_weights(

            checkpoint_path,

        )

        return model